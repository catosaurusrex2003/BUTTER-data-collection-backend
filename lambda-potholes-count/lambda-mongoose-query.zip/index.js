const mongoose = require('mongoose');
const AWS = require('aws-sdk');

// MongoDB connection URI
const mongoURI = 'mongodb+srv://mohammedmehdi:mohammedsmongodbpasswordisthis@cluster0.omq37ht.mongodb.net/ipd?retryWrites=true&w=majority';

// Mongoose model for the collection
const Schema = mongoose.Schema;

const LocationSchema = new Schema({
    name: String,
    location: {
        type: { type: String },
        coordinates: [{ type: Number }],
    },
    numberofPotholes: [{ type: Number }],
});

const Location = mongoose.model("coordinate", LocationSchema);

// Lambda handler function
exports.handler = async (event, context) => {
    context.callbackWaitsForEmptyEventLoop = false; // Prevents Lambda from waiting for the MongoDB connection to close

    await mongoose.connect(mongoURI);

    let queryResult = [];

    // Parse the JSON body from the event
    const requestBody = JSON.parse(event.body);
    const query = requestBody.query;

    // Query the collection
    try {
        queryResult = await Location.find(query);
    } catch (error) {
        console.log(`ERROR while querying database: ${error}`);
    }

    await mongoose.disconnect();

    // Return the documents as JSON
    return {
        statusCode: 200,
        body: JSON.stringify(queryResult),
        headers: {
            'Content-Type': 'application/json'
        }
    };
};
